

<?php $__env->startSection('content'); ?>
    <div class="bg-white shadow rounded p-4 space-y-2">
        <h2 class="text-2xl font-bold">
            <?php echo e($post->title); ?>

        </h2>

        <p>
            <?php echo e($post->content); ?>

        </p>

        <a href="<?php echo e(route('posts.index')); ?>" class="text-gray-600 underline">
            Kembali ke Daftar
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\L  E  N  O  V  O\posts-app\resources\views/posts/show.blade.php ENDPATH**/ ?>