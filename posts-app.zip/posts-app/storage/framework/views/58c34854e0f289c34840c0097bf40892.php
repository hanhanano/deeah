

<?php $__env->startSection('content'); ?>
    <div class="bg-white shadow rounded p-4">
        <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label class="block font-medium">Judul</label>
                <input type="text" name="title" value="<?php echo e($post->title); ?>" class="w-full border rounded px-3 py-2" required>
            </div>

            <div>
                <label class="block font-medium">Konten</label>
                <textarea name="content" rows="4" class="w-full border rounded px-3 py-2" required><?php echo e($post->content); ?></textarea>
            </div>

            <div class="flex items-center space-x-4">
                <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded">
                    Update
                </button>

                <a href="<?php echo e(route('posts.index')); ?>" class="text-gray-600 underline">
                    Kembali
                </a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\L  E  N  O  V  O\posts-app\resources\views/posts/edit.blade.php ENDPATH**/ ?>