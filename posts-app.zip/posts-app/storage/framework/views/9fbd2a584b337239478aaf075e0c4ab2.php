

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('posts.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded mb-4 inline-block">
        Tambah Post
    </a>

    <div class="bg-white shadow rounded p-4">
        <table class="w-full table-auto">
            <thead>
                <tr class="bg-gray-200">
                    <th class="px-4 py-2 text-left">Judul</th>
                    <th class="px-4 py-2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($post->title); ?></td>
                        <td class="border px-4 py-2 text-center space-x-2">
                            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="text-blue-600 underline">
                                Detail
                            </a>
                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="text-yellow-600 underline">
                                Edit
                            </a>
                            <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 underline"
                                    onclick="return confirm('Hapus post ini?')">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\L  E  N  O  V  O\posts-app\resources\views/posts/index.blade.php ENDPATH**/ ?>